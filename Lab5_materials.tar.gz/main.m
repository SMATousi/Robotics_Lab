clc 
clear

system('PumaMoveXYZOAT 0, 200, 0, -90, 90, 0');
while 1
    
    A = object_pick()
end 