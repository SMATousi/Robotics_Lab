function A = object_pick()

system('save_single_image puma2 obj2');


[al, cl, ol] = myobjectdetection('leftobj2.ppm');

[ar, cr, or] = myobjectdetection('rightobj2.ppm');

calib_right = load('puma2/Calib_Results_right.mat');
calib_left = load('puma2/Calib_Results_left.mat');

l_kk = calib_left.KK;
r_kk = calib_right.KK;

l_rc1 = calib_left.Rc_1;
r_rc1 = calib_right.Rc_1;

l_tc1 = calib_left.Tc_1;
r_tc1 = calib_right.Tc_1;




I_l = l_kk;
I_r = r_kk;

E_l = [l_rc1, l_tc1];
E_r = [r_rc1, r_tc1];


ql = I_l*E_l;
qr = I_r*E_r;




M1 = Dreconstruction(qr, ql, cr(1,:), cl(1,:))
% M2 = Dreconstruction(qr, ql, cr(2,:), cl(2,:))
% M3 = Dreconstruction(qr, ql, cr(3,:), cl(3,:))
% M4 = Dreconstruction(qr, ql, cr(4,:), cl(4,:))



world_to_puma_trans = [-392, 292, -325, 1];
world_to_puma_rotation = [0, 1, 0; -1, 0, 0; 0, 0, 1; 0, 0, 0];

world_to_puma = [world_to_puma_rotation, world_to_puma_trans']



COR = world_to_puma * [M1;1]
% COR = [M1;1]' * world_to_puma




system('openGripper &');
% pause (2);

ori_obj = 180 - ol(1);
x_s = num2str(COR(1));
y_s = num2str(COR(2));
z_s = num2str(COR(3) + 125);
cmd1 = sprintf('PumaMoveXYZOAT %g, %g, 0, -90, 90, %g', COR(1), COR(2), ori_obj);
cmd2 = sprintf('PumaMoveXYZOAT %g, %g, %g, -90, 90, %g', COR(1), COR(2), COR(3) + 135, ori_obj);

system(cmd1);
% pause (1);
system(cmd2);
pause (1);
system('closeGripper');
% pause (1);
system(cmd1);
system('PumaMoveXYZOAT 0, 200, 0, -90, 90, 0');
pause (1);
system('openGripper &');
pause (2);
system('closeGripper');

A = 1;

end

