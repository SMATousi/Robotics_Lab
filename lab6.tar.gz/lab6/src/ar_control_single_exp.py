#!/usr/bin/env python
import rospy
import numpy as np
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from geometry_msgs.msg import *
from tf.msg import *
import math
import tf
from tf.transformations import euler_from_quaternion, quaternion_from_euler
from numpy.linalg import inv
# import matplotlib.pyplot as plt

# global flag
flag = False
counter = 0

# pose = 0

# def Position(odom_data): 
#     '''
#     This is the callback function to use for odometry data. We will get the odometry
#     position and orientation here and change a global variable to use this in the 
#     control loop. 
#     '''
#     global pose
#     global counter
#     global roll, pitch, yaw
#     # rospy.sleep(1)
#     curr_time = odom_data.header.stamp
#     pose = odom_data.pose.pose #  the x,y,z pose and quaternion orientation
#     counter= counter+1
#     orientation_q = odom_data.pose.pose.orientation
#     orientation_list = [orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w]
#     (roll, pitch, yaw) = euler_from_quaternion (orientation_list)
#     # print counter, curr_time
#     # print
#     # print pose

#     flag = True

    # rospy.loginfo(flag)


def initilize():
    '''
    This function will initilize the three transforms that we 
    use in the control loop. 
    '''
    sd_transform = np.zeros((4,4)) #sd : source to destination 
    sc_transform = np.zeros((4,4)) #sc : source to current
    cd_transform = np.zeros((4,4)) #cd : current to destination 

    return sd_transform, sc_transform, cd_transform

def build(x,y,yaw):
    '''
    This function will build the transform matrix based on the 
    x, y and the orientation yaw.
    '''
    sd_transform1 = [np.cos(yaw), -np.sin(yaw), 0, x]
    sd_transform2 = [np.sin(yaw), np.cos(yaw), 0, y]
    sd_transform3 = [0, 0, 1, 0]
    sd_transform4 = [0, 0, 0, 1]
    sd_transform = np.array([sd_transform1,sd_transform2,sd_transform3,sd_transform4])
    return sd_transform

def calculate_cd(sd_transform, sc_transform):
    '''
    This function will calculate the current to destination transform
    based on the source to destination and source to current transforms
    '''
    cd_transform = np.matmul(inv(sc_transform), sd_transform)
    # cd_transform = np.matmul(sd_transform, inv(sc_transform))
    return cd_transform

def cartesian_to_polar(yaw, cd_transform):
    '''
    This function will transform the cartesian to polar transformation
    '''
    rho = np.sqrt(cd_transform[0,3]**2 + cd_transform[1,3]**2)
    theta = yaw
    alpha = -theta + np.arctan2(cd_transform[1,3],cd_transform[0,3])
    beta = - (theta + alpha)
    
    
    return rho, alpha, beta

def talker(v, w):
    '''
    The publisher function that publishes the velocity to the robot
    '''
    pub = rospy.Publisher('cmd_vel', Twist, queue_size=1)
    # pub = rospy.Publisher('cmd_vel_', Twist, queue_size=10)
    
    
     # 10hz    
    


    twist_msg = Twist()
    twist_msg.linear.x = v
    twist_msg.angular.z = w
    # rospy.loginfo(twist_msg)

    pub.publish(twist_msg)

def rotate(ang_vel, yaw):

	pub = rospy.Publisher('cmd_vel', Twist, queue_size=100)
	rospy.init_node('navigator', anonymous=True)
	rate = rospy.Rate(10) # 10hz
	twist_msg_ang = Twist()
	twist_msg_ang_stop = Twist()
	twist_msg_ang.angular.z = ang_vel
	twist_msg_ang_stop.angular.z = 0.0

	t2 = rospy.Time.now()
	t1 = rospy.Time.now()

	theta = 1.57 + yaw
	angle = 0

	while angle < theta and (not rospy.is_shutdown()):
	    pub.publish(twist_msg_ang)
	    t2 = rospy.Time.now()
	    duration = (t2 - t1)
	    angle = twist_msg_ang.angular.z * duration.to_sec()
	    rospy.loginfo(angle)


	pub.publish(twist_msg_ang_stop)



def begin():
    '''
    The main control loop
    '''
            
    try:
        while not rospy.is_shutdown():
            global flag
            trajectory = []
            # global pose
            rospy.init_node('navigator', anonymous=True) # initilizing the subscriber node
            # rospy.init_node('turtle_tf_listener')
            listener = tf.TransformListener()
            # rospy.Subscriber('odom',Odometry,Position)
            rate = rospy.Rate(100)

            while not rospy.is_shutdown():
                try:
                    (transd,rotd) = listener.lookupTransform('/world', '/ar_marker', rospy.Time(0))
                    break
                except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
                    print("Waiting")
                    rospy.sleep(0.1)
                    continue

            (rolld, pitchd, yawd) = euler_from_quaternion (rotd)

            
            sd_transform, sc_transform, cd_transform = initilize()

            destination_wrt_marker = build(-0.8,-0.8,0)
            
            # defining the destination coordinates and the control gains
            x,y,dest_yaw = -transd[0], -transd[1], yawd - 1.57

            # sd_transform = build(x,y,dest_yaw)

            

            # x = x - 0.25

            # rospy.loginfo(x)
            # rospy.loginfo(y)

            K_p,K_a,K_b = 0.05,0.0501,-0.5

            sm_transform = build(x,y,dest_yaw)
            sd_transform = np.matmul(destination_wrt_marker, sm_transform)

            rospy.loginfo("sd:" + str(sd_transform))

            # break 
            # rospy.spin()
            rospy.sleep(1)
            # rospy.loginfo(flag)
            # init_x = pose.position.x
            # init_y = pose.position.y
            while not rospy.is_shutdown():
                # break

                try:
                    (trans,rot) = listener.lookupTransform('/world', '/ar_marker', rospy.Time(0))
                except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
                    rospy.sleep(0.1)

                    continue
                
                (roll, pitch, yaw) = euler_from_quaternion (rot)

                yaw = yaw - 1.57
                

                cm_transform = build(-trans[0],-trans[1],yaw)
                cd_transform = np.matmul(destination_wrt_marker, cm_transform)

                rospy.loginfo("cd:" + str(cd_transform))

                rate.sleep()

                sc_transform = np.matmul(sd_transform, inv(cd_transform))

                rospy.loginfo("sc:" + str(sc_transform))

                current_x = sc_transform[0,3]
                current_y = sc_transform[1,3]

                # This is the stopping criteria for the robot when it approaches the destination
                if np.abs(current_x - x) < 0.1 and np.abs(current_y - y) < 0.1:
                    print("BREAK")
                    break

                rospy.loginfo("X:" + str(current_x))
                rospy.loginfo("Y:" + str(current_y))
                ps = [current_x,current_y]
                trajectory.append(ps)
                rospy.loginfo("yaw:" + str(yaw))

                # sc_transform = build(current_x,current_y,yaw)
                # rospy.loginfo(sc_transform)

                # current_rho, current_alpha, current_beta = cartesian_to_polar(sc_transform)

                # cd_transform = calculate_cd(sd_transform, sc_transform)
                # rospy.loginfo(cd_transform)
                rho, alpha, beta = cartesian_to_polar(yaw, cd_transform)

                # diff = [rho, alpha, beta] - [current_rho, current_alpha, current_beta]
                diff = [rho, alpha, beta]
                # rospy.loginfo(diff)

                diff = np.array(diff)

                gains = np.zeros((2,3))

                gains[0,0] = K_p
                gains[1,1] = K_a
                gains[1,2] = K_b
                # rospy.loginfo(gains)

                velocity = np.matmul(gains, np.transpose(diff))
                # break

                talker(velocity[0],velocity[1])

                
                rospy.loginfo("###########" + str(velocity[1]))

                # rospy.loginfo(velocity)

                    # rospy.init_node('odometry', anonymous=True) #make node 
                # rospy.Subscriber('odom',Odometry,Position)
                # control_loop(1,1,0,1,1,1)
            # rospy.spin()
            break
        
        # while not rospy.is_shutdown():
        #     rospy.sleep(1)
        #     rospy.loginfo("########&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&######################")
        #     rotate(0.1, yaw)

        
    
    finally:
        # after ending the main control loop we will save the trajectory of the robot
        # in a numpy file here. 
        trajectory = np.array(trajectory)
        np.save("lab_6_x-08y-08.npy", trajectory)
        print(trajectory.shape)

        
        





if __name__ == "__main__":
    begin()
    
    # rospy.spin() # not really necessary because we have while not rospy.is_shutdown()