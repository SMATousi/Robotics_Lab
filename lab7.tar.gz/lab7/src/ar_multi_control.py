#!/usr/bin/env python
import rospy
import numpy as np
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from geometry_msgs.msg import *
from tf.msg import *
import math
import tf
from tf.transformations import euler_from_quaternion, quaternion_from_euler
from numpy.linalg import inv
from ar_pose.msg import ARMarkers
# from std_msgs.msg import ARMarker
# import matplotlib.pyplot as plt

# global flag
flag = False
counter = 0

conf_matrix = np.zeros((1,4))

# pose = 0

def Position(odom_data): 
    '''
    This is the callback function to use for odometry data. We will get the odometry
    position and orientation here and change a global variable to use this in the 
    control loop. 
    '''
    global pose
    global counter
    global roll, pitch, yaw
    global linear_x
    global angular_z
    # rospy.sleep(1)
    curr_time = odom_data.header.stamp
    pose = odom_data.pose.pose #  the x,y,z pose and quaternion orientation
    linear_x = odom_data.twist.twist.linear.x
    angular_z = odom_data.twist.twist.angular.z
    counter= counter+1
    orientation_q = odom_data.pose.pose.orientation
    orientation_list = [orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w]
    (roll, pitch, yaw) = euler_from_quaternion (orientation_list)
    # print counter, curr_time
    # print
    # print pose

    flag = True

    # rospy.loginfo(flag)

def confidence(data):

    # conf_matrix[]
    data1 = data
    # print(data)

    


def initilize():
    '''
    This function will initilize the three transforms that we 
    use in the control loop. 
    '''
    sd_transform = np.zeros((4,4)) #sd : source to destination 
    sc_transform = np.zeros((4,4)) #sc : source to current
    cd_transform = np.zeros((4,4)) #cd : current to destination 

    return sd_transform, sc_transform, cd_transform

def build(x,y,yaw):
    '''
    This function will build the transform matrix based on the 
    x, y and the orientation yaw.
    '''
    sd_transform1 = [np.cos(yaw), -np.sin(yaw), 0, x]
    sd_transform2 = [np.sin(yaw), np.cos(yaw), 0, y]
    sd_transform3 = [0, 0, 1, 0]
    sd_transform4 = [0, 0, 0, 1]
    sd_transform = np.array([sd_transform1,sd_transform2,sd_transform3,sd_transform4])
    return sd_transform

def calculate_cd(sd_transform, sc_transform):
    '''
    This function will calculate the current to destination transform
    based on the source to destination and source to current transforms
    '''
    cd_transform = np.matmul(inv(sc_transform), sd_transform)
    # cd_transform = np.matmul(sd_transform, inv(sc_transform))
    return cd_transform

def cartesian_to_polar(yaw, cd_transform):
    '''
    This function will transform the cartesian to polar transformation
    '''
    rho = np.sqrt(cd_transform[0,3]**2 + cd_transform[1,3]**2)
    theta = yaw
    alpha = -theta + np.arctan(cd_transform[1,3]/cd_transform[0,3])
    beta = - (theta + alpha)
    
    
    return rho, alpha, beta

def talker(v, w):
    '''
    The publisher function that publishes the velocity to the robot
    '''
    # pub = rospy.Publisher('/ar_multi_control/cmd_vel', Twist, queue_size=1)
    pub = rospy.Publisher('cmd_vel', Twist, queue_size=1)
    
    
     # 10hz    
    


    twist_msg = Twist()

    if np.abs(v) > 0.09 and v > 0:
        v = 0.09
    if np.abs(v) > 0.09 and v < 0:
        v = -0.09
    if np.abs(w) > 0.09 and w > 0:
        w = 0.09
    if np.abs(w) > 0.09 and w < 0:
        w = -0.09
    else:
        v = v
        w = w 
    twist_msg.linear.x = v
    twist_msg.angular.z = w

    rospy.loginfo(twist_msg)

    pub.publish(twist_msg)

def rotate(ang_vel, yawc, iter):

    print("##########################################################################################")

    global yaw
    global angular_z

    pub = rospy.Publisher('cmd_vel', Twist, queue_size=1)
    rospy.init_node('navigator', anonymous=True)
    rospy.Subscriber('odom',Odometry,Position)
    rospy.sleep(0.1)
    rate = rospy.Rate(100) # 10hz
    twist_msg_ang = Twist()
    twist_msg_ang_stop = Twist()
    twist_msg_ang.angular.z = ang_vel
    twist_msg_ang_stop.angular.z = 0.0

    t2 = rospy.Time.now()
    t1 = rospy.Time.now()

    theta = 1.57 + yawc
    if iter == 1:
        theta = theta + 0.23

    if iter == 0:
        theta = theta - 0.10
    
    if iter == 2:
        theta = theta - 0.1
    angle = 0
    current_yaw = yaw

    while np.abs(angle) < np.abs(theta) and (not rospy.is_shutdown()):

        angle_control = angle
        
        pub.publish(twist_msg_ang)
        t2 = rospy.Time.now()
        duration = (t2 - t1)
        angle = (ang_vel - 0.05) * duration.to_sec()
        # angle = yaw - current_yaw 
        rospy.loginfo(angle)
        if np.abs(angle_control - angle) > 1:
            angle = angle_control


	# pub.publish(twist_msg_ang_stop)

def move_lin(dist, lin_vel, iter):
    global linear_x
    print("##########################################################################################")
    pub = rospy.Publisher('cmd_vel', Twist, queue_size=1)
    rospy.init_node('navigator', anonymous=True)
    rospy.Subscriber('odom',Odometry,Position)
    rospy.sleep(0.1)
    rate = rospy.Rate(100) # 10hz
    twist_msg_ang = Twist()
    twist_msg_ang_stop = Twist()
    twist_msg_ang.linear.x = lin_vel
    twist_msg_ang_stop.linear.x = 0.0

    t2 = rospy.Time.now()
    t1 = rospy.Time.now()

    init_x = 0

    while True:
        zero = []
        for i in range(10):
            zero.append(pose.position.x)
        zero = np.array(zero)
        if zero[0] - zero[-1] < 0.0001:
            intialx = zero[-1]
            break
    # current_y = pose.position.y

    line = 0
    line2 = 0

    kp = 0.2

    error = dist - intialx

    if iter == 2 and lin_vel<0:
        dist = dist + 0.05

    while np.abs(line2) < np.abs(dist) and (not rospy.is_shutdown()):
        line_control = line2
        pub.publish(twist_msg_ang)
        error = dist - np.abs(pose.position.x) - np.abs(intialx)
        # command = kp * (error)
        # talker(command, 0)
        t2 = rospy.Time.now()
        duration = (t2 - t1)
        line2 = (linear_x) * duration.to_sec()
        rospy.loginfo("CURRENT" + str(pose.position.x))
        rospy.loginfo("init" + str(intialx))
        rospy.loginfo(line2)
        if np.abs(line_control - line2) > 0.5:
            line2 = line_control

def begin():
    

    '''
    The main control loop
    '''
    c1 = False
    c2 = False
    c3 = False
    c4 = False

    try:
        PROGRAM = True
        while not rospy.is_shutdown() and PROGRAM:

            for iteration in range(0, 4):

                # rospy.loginfo("iteration =====================================" + str(iteration))


                global flag
                trajectory = []
                # global pose
                rospy.init_node('navigator', anonymous=True) # initilizing the subscriber node
                # rospy.init_node('turtle_tf_listener')
                listener = tf.TransformListener()
                rospy.Subscriber('ar_pose_marker',ARMarkers,confidence)
                rospy.Subscriber('odom',Odometry,Position)
                
                rospy.sleep(0.1)
                rate = rospy.Rate(100)

                while not rospy.is_shutdown():

                    # break
                    if iteration == 1:
                        try:
                            (transd4,rotd4) = listener.lookupTransform('/world', '/4x4_4', rospy.Time(0))
                            c4 = True
                            # break
                        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
                            c4 = False
                            print("Waiting4")
                            rospy.sleep(0.1)
                            pass
                    if iteration == 0:    
                        try:
                            (transd3,rotd3) = listener.lookupTransform('/world', '/4x4_3', rospy.Time(0))
                            c3 = True
                            # break
                        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
                            c3 = False
                            print("Waiting3")
                            rospy.sleep(0.1)
                            pass
                    if iteration == 3:
                        try:
                            (transd2,rotd2) = listener.lookupTransform('/world', '/4x4_2', rospy.Time(0))
                            c2 = True
                            # break
                        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
                            c2 = False
                            print("Waiting2")
                            rospy.sleep(0.1)
                            pass
                    if iteration == 2:
                        try:
                            (transd1,rotd1) = listener.lookupTransform('/world', '/4x4_1', rospy.Time(0))
                            c1 = True
                            # break
                        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
                            c1 = False
                            print("Waiting1")
                            rospy.sleep(0.1)
                            pass
                    
                    if not(c1) and not(c2) and not(c3) and not(c4):
                        continue

                    break
                
                if iteration == 2:
                    rotd = rotd1
                    transd = transd1
                elif  iteration == 3:
                    rotd = rotd2
                    transd = transd2
                elif  iteration == 0:
                    rotd = rotd3
                    transd = transd3
                elif  iteration == 1:
                    rotd = rotd4
                    transd = transd4

                (rolld, pitchd, yawd) = euler_from_quaternion (rotd)

                
                sd_transform, sc_transform, cd_transform = initilize()
                
                # defining the destination coordinates and the control gains
                if iteration == 0:
                    thersh = 0.14
                    x,y,dest_yaw = transd[0]-thersh, transd[1], yawd
                elif iteration == 1:
                    thersh = 0.72
                    x,y,dest_yaw = transd[0]-thersh, transd[1], yawd 
                elif iteration == 2:
                    thersh = 0.15
                    x,y,dest_yaw = transd[0]-thersh, transd[1], yawd 
                elif iteration == 3:
                    thersh = 0.25
                    x,y,dest_yaw = transd[0]-thersh, transd[1], yawd 



                rospy.loginfo("destyaw:" + str(yawd + 1.57))

                rospy.loginfo(x)
                rospy.loginfo(y)

                K_p,K_a,K_b = 0.08,0.2,-0.3

                sd_transform = build(x,y,dest_yaw)
                rospy.loginfo(sd_transform)
                # rospy.spin()
                rospy.sleep(1)
                rospy.loginfo(flag)
                # init_x = pose.position.x
                # init_y = pose.position.y
                while not rospy.is_shutdown():
                    # break

                    if iteration == 1:
                    
                        try:
                            (transd4,rotd4) = listener.lookupTransform('/world', '/4x4_4', rospy.Time(0))
                            c4 = True
                            # break
                        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
                            c4 = False
                            print("Waiting4")
                            # rospy.sleep(0.1)
                            break
                        
                    if iteration == 0:
                        try:
                            (transd3,rotd3) = listener.lookupTransform('/world', '/4x4_3', rospy.Time(0))
                            c3 = True
                            # break
                        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
                            c3 = False
                            print("Waiting3")
                            # rospy.sleep(0.1)
                            # print(")))))))))))***********************************************************************************************************************************************************")
                            break
                    if iteration == 3:
                        try:
                            (transd2,rotd2) = listener.lookupTransform('/world', '/4x4_2', rospy.Time(0))
                            c2 = True
                            # break
                        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
                            c2 = False
                            print("Waiting2")
                            # rospy.sleep(0.1)
                            break
                    if iteration == 2:
                        try:
                            (transd1,rotd1) = listener.lookupTransform('/world', '/4x4_1', rospy.Time(0))
                            c1 = True
                            # break
                        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
                            c1 = False
                            print("Waiting1")
                            # rospy.sleep(0.1)
                            break
                    
                    if c1:
                        rotd = rotd1
                        transd = transd1
                    elif  c2:
                        rotd = rotd2
                        transd = transd2
                    elif  c3:
                        rotd = rotd3
                        transd = transd3
                    elif  c4:
                        rotd = rotd4
                        transd = transd4
                    else:
                        print("I CANNOT SEE THE MARKER")
                        break
                    
                    
                    (roll, pitch, yaw) = euler_from_quaternion (rotd)

                    yaw = yaw + 1.57


                    rospy.loginfo("yaw:" + str(yaw))

                    if iteration == 0:
                            
                        cd_transform = build(transd[0]-thersh,transd[1],yaw)
                    
                    elif iteration == 1:

                        cd_transform = build(transd[0]-thersh,transd[1],yaw)

                    elif iteration == 2:

                        cd_transform = build(transd[0]-thersh,transd[1],yaw)

                    elif iteration == 3:

                        cd_transform = build(transd[0]-thersh,transd[1],yaw)




                    rospy.loginfo("cd:" + str(cd_transform))

                    # break

                    rate.sleep()

                    sc_transform = np.matmul(sd_transform, inv(cd_transform))

                    rospy.loginfo("sc:" + str(sc_transform))

                    current_x = sc_transform[0,3]
                    current_y = sc_transform[1,3]

                    # This is the stopping criteria for the robot when it approaches the destination
                    # if np.abs(current_x - x) < 0.05 and np.abs(current_y - y) < 0.05 and np.abs(velocity[1]) < 0.05:
                    #     print("BREAK")
                    #     break
                    
                    

                    rospy.loginfo("X:" + str(current_x))
                    rospy.loginfo("Y:" + str(current_y))
                    ps = [current_x,current_y]
                    trajectory.append(ps)
                    rospy.loginfo("yaw:" + str(yaw))

                    # sc_transform = build(current_x,current_y,yaw)
                    # rospy.loginfo(sc_transform)

                    # current_rho, current_alpha, current_beta = cartesian_to_polar(sc_transform)

                    # cd_transform = calculate_cd(sd_transform, sc_transform)
                    # rospy.loginfo(cd_transform)
                    rho, alpha, beta = cartesian_to_polar(yaw, cd_transform)

                    # diff = [rho, alpha, beta] - [current_rho, current_alpha, current_beta]
                    diff = [rho, alpha, beta]
                    rospy.loginfo(diff)

                    diff = np.array(diff)

                    gains = np.zeros((2,3))

                    gains[0,0] = K_p
                    gains[1,1] = K_a
                    gains[1,2] = K_b
                    # rospy.loginfo(gains)

                    velocity = np.matmul(gains, np.transpose(diff))

                    if iteration == 2:

                        if np.abs(velocity[0])<0.013 and np.abs(velocity[1]) < 0.1:
                            print("BREAK")
                            break
                    elif iteration == 0:
                        if np.abs(velocity[0])<0.013 and np.abs(velocity[1]) < 0.1:
                            print("BREAK")
                            break
                    else:
                        if np.abs(velocity[0])<0.013 and np.abs(velocity[1]) < 0.1:
                            print("BREAK")
                            break

                    rospy.loginfo("velocity:" + str(velocity))

                    # break

                    talker(velocity[0],velocity[1])
                    # rospy.loginfo("###########" + str(velocity[1]))

                    # rospy.loginfo(velocity)

                        # rospy.init_node('odometry', anonymous=True) #make node 
                    # rospy.Subscriber('odom',Odometry,Position)
                    # control_loop(1,1,0,1,1,1)
                
                    # break
                if iteration == 0:

                    rospy.loginfo("########&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&####break##################")
                    rotate(0.3, 0, iteration)
                    rospy.sleep(1)
                    move_lin(0.65, 0.07, iteration)
                    rospy.sleep(1)

                    
                    c_file1 = open('/nfshome/stmmc/Desktop/m_2_r.txt', 'w')
                    c_file1.write('HERE1')
                    c_file1.close()

                    wait = True
                    while wait:
                        rospy.loginfo("******************* WAITING FOR ROBOTIC ARM *************************")
                        c_file2 = open('/nfshome/stmmc/Desktop/r_2_m.txt', 'r')
                        Lines = c_file2.readlines()
                        for line in Lines:
                            for word in line.split():
                                if word == 'DONE1':
                                    rospy.loginfo("&&&&&&&&&&&&&&& THANK YOU!!! &&&&&&&&&&&")
                                    wait = False
                                    
                            
                        
                                





                    move_lin(0.65, -0.07, iteration)
                    rospy.sleep(1)
                    rotate(0.3, 0, iteration)
                    c3 = False

                    


                if iteration == 1:
                    rotate(-0.3, 0, iteration)
                    c4 = False


                if iteration == 2:
                    rotate(0.3, 0, iteration)
                    rospy.sleep(1)
                    move_lin(0.65, 0.07, iteration)
                    rospy.sleep(1)

                    c_file1 = open('/nfshome/stmmc/Desktop/m_2_r.txt', 'w')
                    c_file1.write('HERE2')
                    c_file1.close()

                    wait = True
                    while wait:
                        rospy.loginfo("******************* WAITING FOR ROBOTIC ARM *************************")
                        c_file2 = open('/nfshome/stmmc/Desktop/r_2_m.txt', 'r')
                        Lines = c_file2.readlines()
                        for line in Lines:
                            for word in line.split():
                                if word == 'DONE2':
                                    rospy.loginfo("&&&&&&&&&&&&&&& THANK YOU!!! &&&&&&&&&&&")
                                    wait = False

                    move_lin(0.65, -0.07, iteration)
                    rospy.sleep(1)
                    rotate(0.3, 0, iteration)
                    c1 = False


                if iteration == 3:
                    rotate(-0.3, 0, iteration)
                    move_lin(0.55, 0.07, iteration)
                    PROGRAM = False
                    

            # break
        # break


                # rospy.spin()
        
    finally:
        # after ending the main control loop we will save the trajectory of the robot
        # in a numpy file here. 
        trajectory = np.array(trajectory)
        np.save("multiple_11114_3.npy", trajectory)
        print(trajectory.shape)
        





if __name__ == "__main__":
    begin()
    
    # rospy.spin() # not really necessary because we have while not rospy.is_shutdown()