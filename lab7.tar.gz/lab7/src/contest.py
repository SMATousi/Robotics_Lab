#!/usr/bin/env python
import rospy
import numpy as np
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from geometry_msgs.msg import *
from tf.msg import *
from tf.transformations import euler_from_quaternion, quaternion_from_euler
from numpy.linalg import inv
# import matplotlib.pyplot as plt

# global flag
flag = False
counter = 0


def Position(odom_data): 
    '''
    This is the callback function to use for odometry data. We will get the odometry
    position and orientation here and change a global variable to use this in the 
    control loop. 
    '''
    global pose
    global counter
    global roll, pitch, yaw
    # rospy.sleep(1)
    curr_time = odom_data.header.stamp
    pose = odom_data.pose.pose #  the x,y,z pose and quaternion orientation
    counter= counter+1
    orientation_q = odom_data.pose.pose.orientation
    orientation_list = [orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w]
    (roll, pitch, yaw) = euler_from_quaternion (orientation_list)
    # print counter, curr_time
    # print
    # print pose

    flag = True

    # rospy.loginfo(flag)


def initilize():
    '''
    This function will initilize the three transforms that we 
    use in the control loop. 
    '''
    sd_transform = np.zeros((4,4)) #sd : source to destination 
    sc_transform = np.zeros((4,4)) #sc : source to current
    cd_transform = np.zeros((4,4)) #cd : current to destination 

    return sd_transform, sc_transform, cd_transform

def build(x,y,yaw):
    '''
    This function will build the transform matrix based on the 
    x, y and the orientation yaw.
    '''
    sd_transform1 = [np.cos(yaw), -np.sin(yaw), 0, x]
    sd_transform2 = [np.sin(yaw), np.cos(yaw), 0, y]
    sd_transform3 = [0, 0, 1, 0]
    sd_transform4 = [0, 0, 0, 1]
    sd_transform = np.array([sd_transform1,sd_transform2,sd_transform3,sd_transform4])
    return sd_transform

def calculate_cd(sd_transform, sc_transform):
    '''
    This function will calculate the current to destination transform
    based on the source to destination and source to current transforms
    '''
    cd_transform = np.matmul(inv(sc_transform), sd_transform)
    # cd_transform = np.matmul(sd_transform, inv(sc_transform))
    return cd_transform

def cartesian_to_polar(yaw, cd_transform):
    '''
    This function will transform the cartesian to polar transformation
    '''
    rho = np.sqrt(cd_transform[0,3]**2 + cd_transform[1,3]**2)
    theta = yaw
    alpha = -theta + np.arctan2(cd_transform[1,3],cd_transform[0,3])
    beta = - (theta + alpha)
    
    
    return rho, alpha, beta

def talker(v, w):
    '''
    The publisher function that publishes the velocity to the robot
    '''
    pub = rospy.Publisher('odometry/cmd_vel', Twist, queue_size=1)
    # pub = rospy.Publisher('cmd_vel_', Twist, queue_size=10)
    
    
     # 10hz    
    


    twist_msg = Twist()
    twist_msg.linear.x = v
    twist_msg.angular.z = w
    # rospy.loginfo(twist_msg)

    pub.publish(twist_msg)



def rotate(ang_vel, yawc):

    global yaw

    pub = rospy.Publisher('cmd_vel', Twist, queue_size=1)
    rospy.init_node('navigator', anonymous=True)
    rate = rospy.Rate(10) # 10hz
    twist_msg_ang = Twist()
    twist_msg_ang_stop = Twist()
    twist_msg_ang.angular.z = ang_vel
    twist_msg_ang_stop.angular.z = 0.0

    t2 = rospy.Time.now()
    t1 = rospy.Time.now()

    theta = 1.57 - yawc
    angle = 0
    current_yaw = yaw

    while np.abs(angle) < theta and (not rospy.is_shutdown()):
        pub.publish(twist_msg_ang)
        # t2 = rospy.Time.now()
        # duration = (t2 - t1)
        # angle = (twist_msg_ang.angular.z + 0.16) * duration.to_sec()
        angle = yaw - current_yaw 
        rospy.loginfo(angle)


	pub.publish(twist_msg_ang_stop)

def move_lin(dist, lin_vel):
    print("##########################################################################################")
    pub = rospy.Publisher('cmd_vel', Twist, queue_size=1)
    rospy.init_node('navigator', anonymous=True)
    rate = rospy.Rate(10) # 10hz
    twist_msg_ang = Twist()
    twist_msg_ang_stop = Twist()
    twist_msg_ang.linear.x = lin_vel
    twist_msg_ang_stop.linear.x = 0.0

    t2 = rospy.Time.now()
    t1 = rospy.Time.now()

	while True:
        zero = []
        for i in range(10):
            zero.append(pose.position.x)
        zero = np.array(zero)
        if zero[0] - zero[-1] < 0.0001:
            intialx = zero[-1]
            break
    # current_y = pose.position.y

    line = 0

    while line < dist and (not rospy.is_shutdown()):
        pub.publish(twist_msg_ang)
        line = np.abs(pose.position.x) - np.abs(intialx)
        # t2 = rospy.Time.now()
        # duration = (t2 - t1)
        # line = (twist_msg_ang.linear.x + 0.05) * duration.to_sec()
        rospy.loginfo(line)


    pub.publish(twist_msg_ang_stop)

def begin():
    rospy.init_node('navigator', anonymous=True) # initilizing the subscriber node
    rospy.Subscriber('odom',Odometry,Position)
    rospy.sleep(1)


    # rospy.loginfo("########&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&######################")

    while not rospy.is_shutdown():
        
        rate = rospy.Rate(100)


        # rotate(0.3, 0.0)
        move_lin(0.4, -0.1)
        break


if __name__ == "__main__":
    begin()

