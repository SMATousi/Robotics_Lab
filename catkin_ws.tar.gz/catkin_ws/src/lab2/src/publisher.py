#!/usr/bin/env python
# license removed for brevity
import rospy
from std_msgs.msg import String



def talker():
    my_listener = rospy.SubscribeListener()
    pub = rospy.Publisher('chatter', String, subscriber_listener = my_listener, queue_size=10)
    
    rospy.init_node('talker', anonymous=True)
    rate = rospy.Rate(10) # 10hz
    count=0
    
    
    while not rospy.is_shutdown():
        hello_str = "hello world %s" % count
        while pub.get_num_connections() < 1:
            rospy.loginfo("Waiting")
        rospy.loginfo(hello_str)
        
        pub.publish(hello_str)
        rate.sleep()
        count+=1


if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass